package org.example.views;
import java.util.*;
import org.example.modelos.modelosheladosa;
import org.example.controllers.controllersForts;
import org.example.views.viewshealdosa;

public class viewshealdosa {
    public void mostrarMenu(){
        System.out.println("-------------");
        System.out.println("1. Fortnite");
        System.out.println("2. Comprar Forts");
        System.out.println("3. Salir");
        System.out.println("-------------");
    }

    public void mostrarhelado (int id, String nombre, int uds) {
        System.out.println("Helado ID" + id);
        System.out.println("Nom Helado" + nombre);
        System.out.println("Uds: "+ uds);
    }

    public void pedirId() {
        System.out.println("Ingrese ID: ");
    }
    public void pedirNom() {
        System.out.println("Ingrese Nombre: ");
    }
    public void pedirUds() {
        System.out.println("Ingrese Uds: ");
    }

    public void mostrarCatalogoHelados (List<modelosheladosa> Catalogo){
        System.out.println("Catálogo Helados");
        for ( modelosheladosa e : Catalogo ){
            System.out.println("Id helado: "+ e.getId());
            System.out.println("Nom helado: "+ e.getNom());
            System.out.println("Uds Helado: "+e.getUds());
        }
    }
}
