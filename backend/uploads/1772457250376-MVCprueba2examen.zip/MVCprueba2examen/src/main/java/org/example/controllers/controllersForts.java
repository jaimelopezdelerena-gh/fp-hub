package org.example.controllers;
import java.util.*;
import org.example.modelos.modelosheladosa;
import org.example.controllers.controllersForts;
import org.example.views.viewshealdosa;

import com.sun.source.tree.LiteralTree;

import java.util.List;

public class controllersForts {

    private List<modelosheladosa> listahelados;
    private viewshealdosa vistaHelados;

    public controllersForts(List<modelosheladosa> listahelados, viewshealdosa viewshealdosa) {
        this.listahelados = listahelados;
        this.vistaHelados = viewshealdosa;
    }

    public void agregarHelado(Scanner sc) {
        vistaHelados.pedirId();
        int id = sc.nextInt();
        sc.nextLine();

        vistaHelados.pedirNom();
        String nom = sc.nextLine();

        vistaHelados.pedirUds();
        int uds = sc.nextInt();

        modelosheladosa nuevo = new modelosheladosa(id, nom, uds);
        this.listahelados.add(nuevo);
        System.out.println("Helado ta Bien");
        vistaHelados.mostrarhelado(nuevo.getId(), nuevo.getNom(), nuevo.getUds());

    }

    public void comprarHelados(Scanner sc2) {
        vistaHelados.mostrarCatalogoHelados(listahelados);
        System.out.println("Cual quiere fort?: ");
        String heladoCogido = sc2.nextLine();

        modelosheladosa heladoencontrado = null;
        for (modelosheladosa helado : listahelados) {
            if (helado.getNom().equalsIgnoreCase(heladoCogido)) {
                heladoencontrado = helado;
                break;
            }
        }

        if (heladoCogido != null) {
            System.out.println("Cuantas uds de " + heladoencontrado.getNom() + "?");
            int unidadesCompradas = sc2.nextInt();
            if (unidadesCompradas <= heladoencontrado.getUds()) {
                heladoencontrado.setUds(heladoencontrado.getUds() - unidadesCompradas);
                System.out.println("Has comprado lo q has comprado payo. (" + heladoencontrado.getUds() + ")");
            } else {
                System.out.println("No hay mas payo");
            }

        } else {
            System.out.println("No se encuentra payico");
        }

    }
}
