package org.example.modelos;
import java.util.*;
import org.example.modelos.modelosheladosa;
import org.example.controllers.controllersForts;
import org.example.views.viewshealdosa;

public class modelosheladosa {
    private int id;
    private String nom;
    private int uds;

    public modelosheladosa(int id, String nom, int uds) {
        this.id = id;
        this.nom = nom;
        this.uds = uds;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getUds() {
        return uds;
    }

    public void setUds(int uds) {
        this.uds = uds;
    }
}

