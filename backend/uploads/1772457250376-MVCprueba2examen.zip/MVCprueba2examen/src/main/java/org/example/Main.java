package org.example;
import java.util.*;
import org.example.modelos.modelosheladosa;
import org.example.controllers.controllersForts;
import org.example.views.viewshealdosa;

// me lo ha dicho morillan, te importa todo lo q necesitas payo

public class Main {
    public static void main(String[] args){;

        viewshealdosa vistaHelados = new viewshealdosa();
        List<modelosheladosa> listaHelados = new ArrayList<>();
        controllersForts controladorForts = new controllersForts(listaHelados, vistaHelados);


Scanner sc = new Scanner(System.in);
boolean fin = false;
do{
    vistaHelados.mostrarMenu();
    int opcion = sc.nextInt();
    switch (opcion){
        case 1:
            controladorForts.agregarHelado(sc);
            break;
        case 2:
            controladorForts.comprarHelados(sc);
            break;
        case    3:
            System.out.println("Saliendo del puto programa");
            fin = true;
        default:
            System.out.println("opcion no valida payo mierda");


    }


} while(!fin);


    }
}
